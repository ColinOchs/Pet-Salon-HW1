
let salon={
    name:"The Pampered Pooch",
    address:{
        street:"Clifford Street",
        ZIPcode:"37175",
        number:"867-5309"
    },
    hours:{
        open:"9:00 am",
        close:"5:00 pm"
    }
,
pets: [
    {
        name:"Snoop",
        age:60,
        gender:"male",
        breed:"pitbull",
        service:"grooming",
        owner:"Nate",
        phone:"555-555-5555"
    },
    {
        name:"Buckeye",
        age:34,
        gender:"female",
        breed:"doberman",
        service:"haircut",
        owner:"Ronaldo",
        phone:"555-553-5345"
    },
    {
        name:"Donut",
        age:26,
        gender:"male",
        breed:"chihuahua",
        service:"clipping",
        owner:"Tiffany",
        phone:"555-546-9555"
    },{
        name:"Bitey Face",
        age:17,
        gender:"female",
        breed:"labradoodle",
        service:"grooming",
        owner:"Ralph",
        phone:"555-345-9855"
    }
]

}

console.log(salon.pets);

function displayPetNames(){
    //travel the array
    //display in the console the names
  
        for(let i=0;i<salon.pets.length;i++){
            console.log(salon[pets]);
        }
    }
alert("There are '4' dogs in the client list")

