let names = ["Victoria","Mark","Mike","Phil"];
let mixed= [99, "Derek", true, null, 45, "hello"];

function displayNames(){
    for(let i=0;i<names.length;i++){
        console.log(names[i]);
    }
}
//displayNames();

let ages = [55,45,23,34,55,78];

//travel the ages array

function displayAge(){
    for(let i=0;i<ages.length;i++){
        console.log(ages[i]);
    }
}

//displayAge();

//object literal

let student={
    name:"Joey",
    age:80,
    student:true,
    grade:"A-",
    music:["Eminem","Coldplay","Nirvana"],
    address:{
        city:"San Diego",
        country:"USA"
    }
}
console.log(student.name,student.age);//joey age on console
console.log(student["student"]);//true on console

console.log(student.address.country,student.address.city);//USA san diego
console.log(student.music[2]);//same as line 41
console.log(student["music"][2]);//true

let students=[
    {
        name:"Tom",
        age:27,
        activeStudent:true
    },
    {
        name:"Brad",
        age:49,
        activeStudent:true
    },
    {
        name:"Bill",
        age:23,
        activeStudent:false
    }
]

console.log(students);
console.log(students[0]);